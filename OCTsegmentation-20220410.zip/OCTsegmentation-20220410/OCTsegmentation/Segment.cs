﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace OCTsegmentation
{
    class Segment
    {

        //图像叠加成像
        [DllImport("WAVEGT.dll", EntryPoint = "imageSegment")]
        unsafe public static extern int imageSegment(byte* nameimageup, out double judge);

    }
}
